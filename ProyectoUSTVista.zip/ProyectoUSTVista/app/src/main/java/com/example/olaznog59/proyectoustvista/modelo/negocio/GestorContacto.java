package com.example.olaznog59.proyectoustvista.modelo.negocio;

/**
 * Created by juanmgar on 21/11/16.
 */

public class GestorContacto {
}
